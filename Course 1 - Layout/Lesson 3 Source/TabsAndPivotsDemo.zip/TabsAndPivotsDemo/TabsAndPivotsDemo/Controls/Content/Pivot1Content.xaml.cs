﻿using Windows.UI.Xaml.Controls;

// The User Control item template is documented at http://go.microsoft.com/fwlink/?LinkId=234236

namespace TabsAndPivotsDemo.Controls.Content
{
    public sealed partial class Pivot1Content : UserControl
    {
        public Pivot1Content()
        {
            this.InitializeComponent();
        }
    }
}
